

	function My_First_Function() {
		var String = "Kiss me, I'm Irish!";
		var result = String.fontcolor("green");
		document.getElementById("Irish").innerHTML = 
		result;
		}
